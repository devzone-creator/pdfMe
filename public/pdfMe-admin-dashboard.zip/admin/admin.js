
const correctPassword = "admin123"; // Change as needed

function verifyPassword() {
  const input = document.getElementById("adminPass").value;
  if (input === correctPassword) {
    document.getElementById("protectedContent").style.display = "block";
  } else {
    alert("Incorrect password");
  }
}

async function loadFeedback() {
  try {
    const response = await fetch("/api/feedback");
    const data = await response.json();

    const list = document.getElementById("feedbackList");
    list.innerHTML = "";

    data.forEach(item => {
      const div = document.createElement("div");
      div.className = "feedback-item";
      div.innerHTML = `
        <strong>${item.name}</strong>
        <p>${item.message}</p>
        <div class="feedback-meta">${new Date(item.createdAt).toLocaleString()}</div>
      `;
      list.appendChild(div);
    });
  } catch (err) {
    console.error(err);
    document.getElementById("feedbackList").innerText = "Failed to load feedback.";
  }
}

window.onload = () => {
  // Optional: auto-load feedback if password is removed
};
